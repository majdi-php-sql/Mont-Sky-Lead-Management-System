<?php
////////////////////////////////////////// This System Created By Majdi M. S. Awad //////////////////////////////////////////
// Database configuration
$servername = "localhost";
$username = "root";
$password = "Majdi@00800";
$dbname = "mont";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from the form
$name = $_POST['name'];
$mobile = $_POST['mobile'];
$borough = $_POST['borough'];
$neighborhood = $_POST['neighborhood'];
$type = $_POST['type'];
$channel = $_POST['channel'];

// Get the current date and time
$current_date = date('Y-m-d');
$current_time = date('H:i:s');

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO queries (name, mobile, borough, neighborhood, type, channel, date, time, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'query')");
$stmt->bind_param("ssssssss", $name, $mobile, $borough, $neighborhood, $type, $channel, $current_date, $current_time);

// Execute the statement
if ($stmt->execute()) {
    echo "New record created successfully";
	header("location: https://montskyrealestate.com/");
} else {
    echo "Error: " . $stmt->error;
}

// Close the statement and connection
$stmt->close();
$conn->close();
////////////////////////////////////////// This System Created By Majdi M. S. Awad //////////////////////////////////////////
?>
