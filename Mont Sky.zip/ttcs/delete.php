 <?php
require 'configuration/db_connect.php';

$id = $_GET['id'];
$sql = "DELETE FROM queries WHERE id='$id'";

if ($conn->query($sql) === TRUE) {
  header ('Location: queries.php');
} else {
  echo "Error deleting record: " . $conn->error;
}

$conn->close();
?> 