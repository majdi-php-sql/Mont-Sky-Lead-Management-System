 <?php
////////////////////////////////////////// This System Created By Majdi M. S. Awad //////////////////////////////////////////
// connet to DB
require 'configuration/db_connect.php';

		// I have used the global variable to assign values for the following variables
		$id   = $_POST['id'];
		$name   = $_POST['name'];
		$borough   = $_POST['borough'];
		$neighborhood   = $_POST['neighborhood'];
		$agent   = $_POST['agent'];
		$status     = $_POST['status'];
		$paid  = $_POST['paid'];
		$total_amount   = $_POST['total_amount'];

// I have used UPDATE SET SQL commands 
$sql = "UPDATE queries SET id='$id', name='$name', borough='$borough', neighborhood='$neighborhood', agent='$agent', status='$status', paid='$paid', total_amount='$total_amount' WHERE id=$id";
// Just a normal if condition to make sure that the row updated
if ($conn->query($sql) === TRUE) {
  header ('Location: queries.php');
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
////////////////////////////////////////// This System Created By Majdi M. S. Awad //////////////////////////////////////////
?> 