<?php
////////////////////////////////////////// This System Created By Majdi M. S. Awad //////////////////////////////////////////
// Database configuration
require 'configuration/db_connect.php';

// Get data from the form
$channel = $_POST['channel'];
$expenses = $_POST['expenses'];

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO expenses (channel, expenses) VALUES (?, ?)");
$stmt->bind_param("ss", $channel, $expenses);

// Execute the statement
if ($stmt->execute()) {
    echo "New record created successfully";
    header("Location: expenses.php");
    exit; // Make sure to exit after redirecting
} else {
    echo "Error: " . $stmt->error;
}

// Close the statement and connection
$stmt->close();
$conn->close();
////////////////////////////////////////// This System Created By Majdi M. S. Awad //////////////////////////////////////////
?>
