<?php
session_start();
require 'configuration/db_connect.php';

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

// Access the session data
$agent_id = $_SESSION['user']['agent_id'];
$name = htmlspecialchars($_SESSION['user']['name']);
$email = htmlspecialchars($_SESSION['user']['email']);
$location = htmlspecialchars($_SESSION['user']['location']);
$whatsapp = htmlspecialchars($_SESSION['user']['whatsapp']);

// Query to fetch count of each type
$query = "SELECT type, COUNT(*) as count FROM queries GROUP BY type";
$result = $conn->query($query);

$rentCount = 0;
$buyCount = 0;

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if ($row['type'] == 'rent') {
            $rentCount = $row['count'];
        } elseif ($row['type'] == 'buy') {
            $buyCount = $row['count'];
        }
    }
}

$totalCount = $rentCount + $buyCount;
$rentPercentage = ($totalCount > 0) ? ($rentCount / $totalCount) * 100 : 0;
$buyPercentage = ($totalCount > 0) ? ($buyCount / $totalCount) * 100 : 0;
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>New York Real Estate, Properties and Apartments | Mont Sky Real Estate</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            text-align: center;
            margin: 0;
        }
        #myPieChart {
            width: 500px !important;
            height: 500px !important;
        }
        p {
            max-width: 600px;
            margin: 20px;
        }
    </style>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>

    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./">MONT SKY</a>
                <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Campaign Results</h3>
                    <li>
                        <a href="queries.php"> <i class="menu-icon fa fa-question-circle"></i>Queries </a>
                    </li>
                    <li>
                        <a href="leads.php"> <i class="menu-icon fa fa-users"></i>Leads </a>
                    </li>
                    <li>
                        <a href="potential_clients.php"> <i class="menu-icon fa fa-smile-o"></i>Potential Clients </a>
                    </li>
                    <li>
                        <a href="clients.php"> <i class="menu-icon fa fa-thumbs-up"></i>Clients </a>
                    </li>
                    <li>
                        <a href="losed.php"> <i class="menu-icon fa fa-frown-o"></i>Losed </a>
                    </li>
                    <h3 class="menu-title">Reports & Analysis</h3>
                    <li>
                        <a href="general_report.php"> <i class="menu-icon fa fa-file"></i>General Report </a>
                    </li>
                    <li>
                        <a href="channels_report.php"> <i class="menu-icon fa fa-desktop"></i>Channels </a>
                    </li>
                    <li>
                        <a href="locations_report.php"> <i class="menu-icon fa fa-map-marker"></i>Locations </a>
                    </li>
                    <li class="active">
                        <a href="properties_report.php"> <i class="menu-icon fa fa-home"></i>Properties </a>
                    </li>
                    <h3 class="menu-title">Financial Reports</h3>
                    <li>
                        <a href="expenses.php"> <i class="menu-icon fa fa-credit-card"></i>Expenses </a>
                    </li>
                    <li>
                        <a href="income.php"> <i class="menu-icon fa fa-money"></i>Income </a>
                    </li>
                    <li>
                        <a href="roi.php"> <i class="menu-icon fa fa-bar-chart-o"></i>ROI </a>
                    </li>
                    <h3 class="menu-title">System</h3>
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-out"></i>Logout </a>
                    </li>
                </ul>
            </div>
        </nav>
    </aside>

    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
        <header id="header" class="header">
            <div class="header-menu">
                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa-tasks"></i></a>
                    <div class="header-left">
                        <h4><?php echo $name; ?>, Where our business thrives?</h4>
                    </div>
                </div>
            </div>
        </header>

        <!-- Content -->
        <div style="align:center;" class="content mt-3">
    <canvas id="myPieChart"></canvas>
    <script>
        var ctx = document.getElementById('myPieChart').getContext('2d');
        var myPieChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Rent', 'Buy'],
                datasets: [{
                    data: [<?php echo $rentCount; ?>, <?php echo $buyCount; ?>],
                    backgroundColor: ['#FF6384', '#36A2EB'],
                }]
            },
            options: {
                responsive: false,  // Set to false to respect fixed size
                maintainAspectRatio: false  // Prevents maintaining the aspect ratio
            }
        });
    </script>

    <p>
        In the given dataset, the 'rent' channel accounts for <?php echo $rentCount; ?> queries, 
        which is <?php echo round($rentPercentage, 2); ?>% of the total queries. On the other hand, the 'buy' channel 
        accounts for <?php echo $buyCount; ?> queries, representing <?php echo round($buyPercentage, 2); ?>% of the total queries.
        This indicates that there is a higher interest in <?php echo ($rentCount > $buyCount) ? 'renting' : 'buying'; ?> 
        as compared to <?php echo ($rentCount > $buyCount) ? 'buying' : 'renting'; ?>.
    </p>


</body>

</html>
