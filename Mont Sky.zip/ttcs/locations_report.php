<?php
session_start();
require 'configuration/db_connect.php';

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

// Access the session data
$agent_id = $_SESSION['user']['agent_id'];
$name = htmlspecialchars($_SESSION['user']['name']);
$email = htmlspecialchars($_SESSION['user']['email']);
$location = htmlspecialchars($_SESSION['user']['location']);
$whatsapp = htmlspecialchars($_SESSION['user']['whatsapp']);

// Fetch data from the database
$query = "SELECT borough, COUNT(*) as count FROM queries GROUP BY borough";
$result = $conn->query($query);

$boroughData = [];
$total = 0;

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $boroughData[$row['borough']] = $row['count'];
        $total += $row['count'];
    }
}

// Calculate percentages
$boroughPercentages = [];
foreach ($boroughData as $borough => $count) {
    $boroughPercentages[$borough] = ($count / $total) * 100;
}

// Generate the comparison paragraph
function generateParagraph($boroughPercentages) {
    arsort($boroughPercentages);
    $paragraph = "Based on the gathered data, the distribution of queries across the NYC boroughs is as follows:<br><ul>";
    foreach ($boroughPercentages as $borough => $percentage) {
        $paragraph .= "<ul><strong>$borough</strong>: " . number_format($percentage, 2) . "%</ul>";
    }
    $paragraph .= "</ul>";

    $highestBorough = array_keys($boroughPercentages)[0];
    $lowestBorough = array_keys($boroughPercentages)[count($boroughPercentages) - 1];

    $paragraph .= "<p>This distribution reveals <strong>$highestBorough</strong> as the borough with the highest percentage of queries, attributed to its unique characteristics and appeal. ";
    if (count($boroughPercentages) > 1) {
        $paragraph .= "In contrast, <strong>$lowestBorough</strong> has the lowest percentage of queries, which may be due to different factors affecting its relevance.";
    }
    $paragraph .= "</p>";

    return $paragraph;
}

$comparisonParagraph = generateParagraph($boroughPercentages);
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>New York Real Estate, Properties and Apartments | Mont Sky Real Estate</title>
    <script src="https://d3js.org/d3.v6.min.js"></script>
    <style>
        .tooltip {
            position: absolute;
            text-align: center;
            width: 60px;
            height: 28px;
            padding: 2px;
            font: 12px sans-serif;
            background: lightsteelblue;
            border: 0px;
            border-radius: 8px;
            pointer-events: none;
        }
        #pie-chart {
            width: 100%;
            height: 600px;
        }
    </style>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>

    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./">MONT SKY</a>
                <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Campaign Results</h3>
                    <li>
                        <a href="queries.php"> <i class="menu-icon fa fa-question-circle"></i>Queries </a>
                    </li>
                    <li>
                        <a href="leads.php"> <i class="menu-icon fa fa-users"></i>Leads </a>
                    </li>
                    <li>
                        <a href="potential_clients.php"> <i class="menu-icon fa fa-smile-o"></i>Potential Clients </a>
                    </li>
                    <li>
                        <a href="clients.php"> <i class="menu-icon fa fa-thumbs-up"></i>Clients </a>
                    </li>
                    <li>
                        <a href="losed.php"> <i class="menu-icon fa fa-frown-o"></i>Losed </a>
                    </li>
                    <h3 class="menu-title">Reports & Analysis</h3>
                    <li>
                        <a href="general_report.php"> <i class="menu-icon fa fa-file"></i>General Report </a>
                    </li>
                    <li>
                        <a href="channels_report.php"> <i class="menu-icon fa fa-desktop"></i>Channels </a>
                    </li>
                    <li class="active">
                        <a href="locations_report.php"> <i class="menu-icon fa fa-map-marker"></i>Locations </a>
                    </li>
                    <li>
                        <a href="properties_report.php"> <i class="menu-icon fa fa-home"></i>Properties </a>
                    </li>
                    <h3 class="menu-title">Financial Reports</h3>
                    <li>
                        <a href="expenses.php"> <i class="menu-icon fa fa-credit-card"></i>Expenses </a>
                    </li>
                    <li>
                        <a href="income.php"> <i class="menu-icon fa fa-money"></i>Income </a>
                    </li>
                    <li>
                        <a href="roi.php"> <i class="menu-icon fa fa-bar-chart-o"></i>ROI </a>
                    </li>
                    <h3 class="menu-title">System</h3>
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-out"></i>Logout </a>
                    </li>
                </ul>
            </div>
        </nav>
    </aside>

    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
        <header id="header" class="header">
            <div class="header-menu">
                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa-tasks"></i></a>
                    <div class="header-left">
                        <h4><?php echo $name; ?>, Where our business thrives?</h4>
                    </div>
                </div>
            </div>
        </header>

        <!-- Content -->
        <div style="align:center;" class="content mt-3">
		    <div style="align:center;" id="pie-chart"></div>
    <div style="align:center;" id="comparison-paragraph">
        <?php echo $comparisonParagraph; ?>
    </div>
    <script>
        const boroughPercentages = <?php echo json_encode($boroughPercentages); ?>;
        
        const data = Object.entries(boroughPercentages).map(([key, value]) => {
            return {borough: key, percentage: value};
        });

        const width = 500;
        const height = 500;
        const radius = Math.min(width, height) / 2;

        const color = d3.scaleOrdinal(d3.schemeCategory10);

        const svg = d3.select("#pie-chart").append("svg")
            .attr("width", width)
            .attr("height", height)
            .append("g")
            .attr("transform", `translate(${width / 2}, ${height / 2})`);

        const pie = d3.pie().value(d => d.percentage);

        const arc = d3.arc()
            .outerRadius(radius - 10)
            .innerRadius(0);

        const labelArc = d3.arc()
            .outerRadius(radius - 40)
            .innerRadius(radius - 40);

        const g = svg.selectAll(".arc")
            .data(pie(data))
            .enter().append("g")
            .attr("class", "arc");

        g.append("path")
            .attr("d", arc)
            .style("fill", d => color(d.data.borough));

        g.append("text")
            .attr("transform", d => `translate(${labelArc.centroid(d)})`)
            .attr("dy", ".35em")
            .text(d => `${d.data.borough}: ${d.data.percentage.toFixed(2)}%`);

        // Tooltip
        const tooltip = d3.select("body").append("div")
            .attr("class", "tooltip")
            .style("opacity", 0);

        g.on("mouseover", function(event, d) {
            tooltip.transition()
                .duration(200)
                .style("opacity", .9);
            tooltip.html(`${d.data.borough}: ${d.data.percentage.toFixed(2)}%`)
                .style("left", (event.pageX + 5) + "px")
                .style("top", (event.pageY - 28) + "px");
        })
        .on("mouseout", function(d) {
            tooltip.transition()
                .duration(500)
                .style("opacity", 0);
        });
    </script>


</body>

</html>
