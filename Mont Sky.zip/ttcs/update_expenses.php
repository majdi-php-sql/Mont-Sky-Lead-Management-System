 <?php
////////////////////////////////////////// This System Created By Majdi M. S. Awad //////////////////////////////////////////
// connet to DB
require 'configuration/db_connect.php';

		// I have used the global variable to assign values for the following variables
		$id   = $_POST['id'];
		$expenses   = $_POST['expenses'];

// I have used UPDATE SET SQL commands 
$sql = "UPDATE expenses SET id='$id', expenses='$expenses' WHERE id=$id";
// Just a normal if condition to make sure that the row updated
if ($conn->query($sql) === TRUE) {
  header ('Location: expenses.php');
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
////////////////////////////////////////// This System Created By Majdi M. S. Awad //////////////////////////////////////////
?> 