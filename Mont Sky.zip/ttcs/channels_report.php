<?php
session_start();
require 'configuration/db_connect.php';

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

// Access the session data
$agent_id = $_SESSION['user']['agent_id'];
$name = htmlspecialchars($_SESSION['user']['name']);
$email = htmlspecialchars($_SESSION['user']['email']);
$location = htmlspecialchars($_SESSION['user']['location']);
$whatsapp = htmlspecialchars($_SESSION['user']['whatsapp']);

require 'configuration/db_connect.php';

// Fetch data from the database
$query = "SELECT channel, COUNT(*) as count FROM queries GROUP BY channel";
$result = $conn->query($query);

$channels = [];
$counts = [];
$total = 0;

while ($row = $result->fetch_assoc()) {
    $channels[] = $row['channel'];
    $counts[] = $row['count'];
    $total += $row['count'];
}

// Calculate percentages
$percentages = [];
foreach ($counts as $count) {
    $percentages[] = round(($count / $total) * 100, 2);
}

// Generate the dynamic paragraph
$paragraph = "The distribution of queries across different channels is as follows: ";
for ($i = 0; $i < count($channels); $i++) {
    $paragraph .= ucfirst(str_replace('_', ' ', $channels[$i])) . " accounts for " . $percentages[$i] . "%";
    if ($i < count($channels) - 1) {
        $paragraph .= ", ";
    }
    if ($i == count($channels) - 2) {
        $paragraph .= "and ";
    }
}
$paragraph .= ".";

$conn->close();
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>New York Real Estate, Properties and Apartments | Mont Sky Real Estate</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>

    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./">MONT SKY</a>
                <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Campaign Results</h3>
                    <li>
                        <a href="queries.php"> <i class="menu-icon fa fa-question-circle"></i>Queries </a>
                    </li>
                    <li>
                        <a href="leads.php"> <i class="menu-icon fa fa-users"></i>Leads </a>
                    </li>
                    <li>
                        <a href="potential_clients.php"> <i class="menu-icon fa fa-smile-o"></i>Potential Clients </a>
                    </li>
                    <li>
                        <a href="clients.php"> <i class="menu-icon fa fa-thumbs-up"></i>Clients </a>
                    </li>
                    <li>
                        <a href="losed.php"> <i class="menu-icon fa fa-frown-o"></i>Losed </a>
                    </li>
                    <h3 class="menu-title">Reports & Analysis</h3>
                    <li>
                        <a href="general_report.php"> <i class="menu-icon fa fa-file"></i>General Report </a>
                    </li>
                    <li class="active">
                        <a href="channels_report.php"> <i class="menu-icon fa fa-desktop"></i>Channels </a>
                    </li>
                    <li>
                        <a href="locations_report.php"> <i class="menu-icon fa fa-map-marker"></i>Locations </a>
                    </li>
                    <li>
                        <a href="properties_report.php"> <i class="menu-icon fa fa-home"></i>Properties </a>
                    </li>
                    <h3 class="menu-title">Financial Reports</h3>
                    <li>
                        <a href="expenses.php"> <i class="menu-icon fa fa-credit-card"></i>Expenses </a>
                    </li>
                    <li>
                        <a href="income.php"> <i class="menu-icon fa fa-money"></i>Income </a>
                    </li>
                    <li>
                        <a href="roi.php"> <i class="menu-icon fa fa-bar-chart-o"></i>ROI </a>
                    </li>
                    <h3 class="menu-title">System</h3>
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-out"></i>Logout </a>
                    </li>
                </ul>
            </div>
        </nav>
    </aside>

    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
        <header id="header" class="header">
            <div class="header-menu">
                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa-tasks"></i></a>
                    <div class="header-left">
                        <h4><?php echo $name; ?>, What is the best channel?</h4>
                    </div>
                </div>
            </div>
        </header>

        <!-- Content -->
        <div class="content mt-3">
		    <p><?php echo $paragraph; ?></p>
    <canvas id="channelChart" width="400" height="200"></canvas>
    <script>
        // Data passed from PHP to JS
        var channels = <?php echo json_encode($channels); ?>;
        var percentages = <?php echo json_encode($percentages); ?>;

        var ctx = document.getElementById('channelChart').getContext('2d');
        var channelChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: channels,
                datasets: [{
                    label: 'Percentage of Each Channel',
                    data: percentages,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(201, 203, 207, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)',
                        'rgba(201, 203, 207, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {return value + "%";}
                        }
                    }
                }
            }
        });
    </script>

</body>

</html>
