<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

// Access the session data
$agent_id = $_SESSION['user']['agent_id'];
$name = $_SESSION['user']['name'];
$email = $_SESSION['user']['email'];
$location = $_SESSION['user']['location'];
$whatsapp = $_SESSION['user']['whatsapp'];
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>New York Real Estate, Properties and Apartments | Mont Sky Real Estate</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">


    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>


    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./">MONT SKY</a>
                <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Campaign Results</h3><!-- /.menu-title -->
                    <li>
                        <a href="queries.php"> <i class="menu-icon fa fa-question-circle"></i>Queries </a>
                    </li>
                    <li>
                        <a href="leads.php"> <i class="menu-icon fa fa-users"></i>Leads </a>
                    </li>
                    <li>
                        <a href="potential_clients.php"> <i class="menu-icon fa fa-smile-o"></i>Potential Clients </a>
                    </li>
					<li>
                        <a href="clients.php"> <i class="menu-icon fa fa-thumbs-up"></i>Clients </a>
                    </li>
					<li>
                        <a href="losed.php"> <i class="menu-icon fa fa-frown-o"></i>Losed </a>
                    </li>
                    <h3 class="menu-title">Reports & Analysis</h3><!-- /.menu-title -->

                    <li>
                        <a href="general_report.php"> <i class="menu-icon fa fa-file"></i>General Report </a>
                    </li>
					<li>
                        <a href="channels_report.php"> <i class="menu-icon fa fa-desktop"></i>Channels </a>
                    </li>
                    <li>
                        <a href="locations_report.php"> <i class="menu-icon fa fa-map-marker"></i>Locations </a>
                    </li>
                    <li>
                        <a href="properties_report.php"> <i class="menu-icon fa fa-home"></i>Properties </a>
                    </li>
                    <h3 class="menu-title">Financial Reports</h3><!-- /.menu-title -->
                    <li>
                        <a href="expenses.php"> <i class="menu-icon fa fa-credit-card"></i>Expenses </a>
                    </li>
					<li>
                        <a href="income.php"> <i class="menu-icon fa fa-money"></i>Income </a>
                    </li>
					<li>
                        <a href="roi.php"> <i class="menu-icon fa fa-bar-chart-o"></i>ROI </a>
                    </li>
					<h3 class="menu-title">System</h3><!-- /.menu-title -->
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-out"></i>Logout </a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
						<h2>Welcome <?php echo htmlspecialchars($name); ?>!</h2>
                    <div class="form-inline">
                        </div>     
                </div>
            </div>

        </header><!-- /header -->
        <!-- Header-->

        <div class="content mt-3">
<?php
require 'configuration/db_connect.php';

// Fetch data for the number of records based on created_at
$result = $conn->query("SELECT DATE(created_at) as date, COUNT(*) as count FROM queries GROUP BY DATE(created_at)");
if ($result === false) {
    die("Error fetching data for number of records: " . mysqli_error($conn));
}
$created_at_data = [];
while($row = $result->fetch_assoc()) {
    $created_at_data[] = $row;
}

// Fetch data for the percentage of each status
$result = $conn->query("SELECT status, COUNT(*) as count FROM queries GROUP BY status");
if ($result === false) {
    die("Error fetching data for status: " . mysqli_error($conn));
}
$status_data = [];
while($row = $result->fetch_assoc()) {
    $status_data[] = $row;
}

// Fetch data for the percentage of each type
$result = $conn->query("SELECT type, COUNT(*) as count FROM queries GROUP BY type");
if ($result === false) {
    die("Error fetching data for type: " . mysqli_error($conn));
}
$type_data = [];
while($row = $result->fetch_assoc()) {
    $type_data[] = $row;
}

// Fetch data for the percentage of each borough
$result = $conn->query("SELECT borough, COUNT(*) as count FROM queries GROUP BY borough");
if ($result === false) {
    die("Error fetching data for borough: " . mysqli_error($conn));
}
$borough_data = [];
while($row = $result->fetch_assoc()) {
    $borough_data[] = $row;
}

// Fetch data for the percentage of each channel
$result = $conn->query("SELECT channel, COUNT(*) as count FROM queries GROUP BY channel");
if ($result === false) {
    die("Error fetching data for channel: " . mysqli_error($conn));
}
$channel_data = [];
while($row = $result->fetch_assoc()) {
    $channel_data[] = $row;
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .container {
            display: flex;
            flex-wrap: wrap;
        }
        .chart-container {
            width: 50%;
            padding: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="chart-container">
        <canvas id="createdAtChart"></canvas>
    </div>
    <div class="chart-container">
        <canvas id="statusChart"></canvas>
    </div>
    <div class="chart-container">
        <canvas id="typeChart"></canvas>
    </div>
    <div class="chart-container">
        <canvas id="boroughChart"></canvas>
    </div>
    <div class="chart-container">
        <canvas id="channelChart"></canvas>
    </div>
</div>

<script>
    // Data from PHP
    const createdAtData = <?php echo json_encode($created_at_data); ?>;
    const statusData = <?php echo json_encode($status_data); ?>;
    const typeData = <?php echo json_encode($type_data); ?>;
    const boroughData = <?php echo json_encode($borough_data); ?>;
    const channelData = <?php echo json_encode($channel_data); ?>;

    // Process createdAtData for the line chart
    const createdAtLabels = createdAtData.map(item => item.date);
    const createdAtCounts = createdAtData.map(item => item.count);

    // Create the line chart for createdAtData
    new Chart(document.getElementById('createdAtChart'), {
        type: 'line',
        data: {
            labels: createdAtLabels,
            datasets: [{
                label: 'Number of Records',
                data: createdAtCounts,
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1,
                fill: false
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'Number of Records Based on Created At'
            }
        }
    });

    // Process statusData for the pie chart
    const statusLabels = statusData.map(item => item.status);
    const statusCounts = statusData.map(item => item.count);

    // Create the pie chart for statusData
    new Chart(document.getElementById('statusChart'), {
        type: 'pie',
        data: {
            labels: statusLabels,
            datasets: [{
                label: 'Status',
                data: statusCounts,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'Percentage of Each Status'
            }
        }
    });

    // Process typeData for the pie chart
    const typeLabels = typeData.map(item => item.type);
    const typeCounts = typeData.map(item => item.count);

    // Create the pie chart for typeData
    new Chart(document.getElementById('typeChart'), {
        type: 'pie',
        data: {
            labels: typeLabels,
            datasets: [{
                label: 'Type',
                data: typeCounts,
                backgroundColor: [
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(75, 192, 192, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 159, 64, 1)',
                    'rgba(75, 192, 192, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'Percentage of Each Type'
            }
        }
    });

    // Process boroughData for the pie chart
    const boroughLabels = boroughData.map(item => item.borough);
    const boroughCounts = boroughData.map(item => item.count);

    // Create the pie chart for boroughData
    new Chart(document.getElementById('boroughChart'), {
        type: 'pie',
        data: {
            labels: boroughLabels,
            datasets: [{
                label: 'Borough',
                data: boroughCounts,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'Percentage of Each Borough'
            }
        }
    });

    // Process channelData for the pie chart
    const channelLabels = channelData.map(item => item.channel);
    const channelCounts = channelData.map(item => item.count);

    // Create the pie chart for channelData
    new Chart(document.getElementById('channelChart'), {
        type: 'pie',
        data: {
            labels: channelLabels,
            datasets: [{
                label: 'Channel',
                data: channelCounts,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(201, 203, 207, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(201, 203, 207, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'Percentage of Each Channel'
            }
        }
    });
</script>

</body>
</html>

        </div> <!-- .content -->
    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script>
        (function($) {
            "use strict";

            jQuery('#vmap').vectorMap({
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: ['#1de9b6', '#03a9f5'],
                normalizeFunction: 'polynomial'
            });
        })(jQuery);
    </script>

</body>

</html>
