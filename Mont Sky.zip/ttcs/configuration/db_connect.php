<?php
////////////////////////////////////////// This System Created By Majdi M. S. Awad //////////////////////////////////////////
$servername = "localhost";
$username = "root";
$password = "Majdi@00800";
$dbname = "mont";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
////////////////////////////////////////// This System Created By Majdi M. S. Awad //////////////////////////////////////////
?>


